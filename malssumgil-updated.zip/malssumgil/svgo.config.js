/* SVGO 설정 — 말씀의 길 아이콘(단색 라인)용
 *   npm install            (svgo 설치)
 *   npm run icons          icons/src/*.svg → icons/dist/*.svg 로 최적화
 *
 * 주의: convertColors.currentColor 는 "단색" 아이콘 전용입니다.
 *       다색 앱 아이콘(icons/icon.svg)은 icons/src 에 넣지 마세요. */
/** @type {import('svgo').Config} */
module.exports = {
  multipass: true,
  js2svg: { pretty: false },
  plugins: [
    {
      name: 'preset-default',
      params: {
        overrides: {
          // viewBox는 유지 (CSS로 크기 조절·반응형에 필요)
          removeViewBox: false,
          // 곡선이 깨지지 않도록 소수 2자리까지 유지
          convertPathData: { floatPrecision: 2 }
        }
      }
    },
    // 고정 색 → currentColor (부모 CSS의 color를 따라감)
    { name: 'convertColors', params: { currentColor: true } },
    // width/height 제거 → CSS로 크기 지정
    'removeDimensions'
  ]
};
