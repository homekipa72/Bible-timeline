/* storage.js — localStorage 안전 래퍼 */
'use strict';
// ===== 안전한 저장소 래퍼 =====
// 사생활 보호 모드·저장 공간 부족·손상된 데이터가 있어도 앱이 멈추지 않도록
// localStorage 접근을 모두 이 래퍼(store)로 처리합니다. 저장이 막히면 이 화면에서만 임시 보관합니다.
const store=(function(){
  const mem=Object.create(null);
  let real=null,warned=false;
  try{ real=window.localStorage; real.setItem('__mg_probe','1'); real.removeItem('__mg_probe'); }catch(e){ real=null; }
  function warn(msg){ if(warned)return; warned=true; try{ if(typeof toast==='function')toast(msg); }catch(e){} }
  if(!real) setTimeout(()=>warn('이 브라우저에서는 저장이 막혀 있어, 화면을 닫으면 기록이 사라집니다. 백업을 내려받아 주세요.'),1500);
  const api={
    getItem(k){ k=String(k); if(k in mem)return mem[k]; if(real){ try{ return real.getItem(k); }catch(e){} } return null; },
    setItem(k,v){
      k=String(k); v=String(v);
      if(real){ try{ real.setItem(k,v); delete mem[k]; return true; }catch(e){ warn('저장 공간이 부족하거나 저장할 수 없습니다. 통독 기록 탭에서 백업을 내려받아 주세요.'); } }
      mem[k]=v; return false;
    },
    removeItem(k){ k=String(k); delete mem[k]; if(real){ try{ real.removeItem(k); }catch(e){} } }
  };
  return new Proxy(api,{
    get(t,p){ if(typeof p==='symbol')return undefined; if(p in api)return api[p]; const v=api.getItem(p); return v===null?undefined:v; },
    set(t,p,v){ api.setItem(p,v); return true; },
    deleteProperty(t,p){ api.removeItem(p); return true; },
    has(t,p){ return (p in api)||api.getItem(p)!==null; }
  });
})();
function isPlainObj(v){ return !!v&&typeof v==='object'&&!Array.isArray(v); }
// 예전 버전의 화면 테마(다크 모드) 설정은 더 이상 쓰지 않으므로 정리합니다.
try{ store.removeItem('themePref'); }catch(e){}
// 저장된 JSON을 읽습니다. 없거나·손상되었거나·형태가 다르면 기본값을 돌려주고, 손상본은 복구용으로 따로 남깁니다.
function jget(key,fallback,valid){
  let raw=null;
  try{
    raw=store.getItem(key);
    if(raw==null||raw==='')return fallback;
    const v=JSON.parse(raw);
    if(valid&&!valid(v))throw new Error('unexpected shape');
    return v;
  }catch(e){
    try{ if(raw)store.setItem(key+'__corrupt',String(raw).slice(0,200000)); }catch(_){}
    return fallback;
  }
}
