# 원본 단색 아이콘 SVG를 여기에 넣고 `npm run icons` 를 실행하면 icons/dist 에 최적화본이 만들어집니다.
